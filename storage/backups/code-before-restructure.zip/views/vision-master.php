<?php $visionData = $error && ($_POST['action'] ?? '') === 'vision_save' ? $_POST : visionContent(); ?>
<form method="post" class="panel">
<?= csrf() ?>
<input type="hidden" name="action" value="vision_save">
<h2>Visi, Misi, Janji, Motto &amp; Nilai-Nilai</h2>
<p class="muted">Kelola seluruh isi halaman di sini. Tambahkan poin Misi dan Nilai-Nilai dengan tombol +. Bagian yang kosong tidak ditampilkan di website.</p>
<label>Visi<textarea name="vision" rows="4" maxlength="5000"><?= e($visionData['vision'] ?? '') ?></textarea></label>
<?php $listKey = 'missions'; $listLabel = 'Misi'; require __DIR__ . '/vision-list-editor.php'; ?>
<label>Janji<textarea name="promise" rows="3" maxlength="5000"><?= e($visionData['promise'] ?? '') ?></textarea></label>
<label>Motto<textarea name="motto" rows="2" maxlength="5000"><?= e($visionData['motto'] ?? '') ?></textarea></label>
<?php $listKey = 'values'; $listLabel = 'Nilai-Nilai'; require __DIR__ . '/vision-list-editor.php'; ?>
<button class="button">Simpan semua</button>
</form>
<script src="assets/vision-editor.js?v=<?= filemtime(dirname(__DIR__) . '/assets/vision-editor.js') ?>" defer></script>
