<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex">
<title>
<?=e($modules[$tab])?> • Admin RSBL</title>
<link rel="stylesheet" href="assets/style.css">
<link rel="stylesheet" href="assets/admin-partners.css?v=<?= filemtime(dirname(__DIR__) . '/assets/admin-partners.css') ?>">
<link rel="stylesheet" href="assets/leader-photo.css?v=<?= filemtime(dirname(__DIR__) . '/assets/leader-photo.css') ?>">
<script src="assets/app.js" defer>
</script>
<script src="assets/slide-display.js" defer>
</script>
<link rel="stylesheet" href="assets/slide-display.css?v=<?= filemtime(dirname(__DIR__) . '/assets/slide-display.css') ?>">
<link rel="stylesheet" href="assets/history-editor.css">
<script src="assets/history-editor.js" defer></script>
<script src="assets/doctor-schedule-editor.js" defer></script>
<link rel="stylesheet" href="assets/doctor-schedule-editor.css">
</head>
<body class="admin-body">
<aside class="sidebar">
<a class="brand" href="index.php?page=admin">
<span class="brand-symbol">✦</span>
<span>RS Bintang Laut<small>PANEL PENGELOLA</small>
</span>
</a>
<p class="eyebrow">WORKSPACE</p>
<nav>
<?php foreach($modules as $slug=>$label):?>
<a class="<?=$slug===$tab?'selected':''?>" href="index.php?page=admin&tab=<?=$slug?>">
<?=e($label)?>
</a>
<?php endforeach;?>
</nav>
<div class="sidebar-bottom">
<a href="index.php" target="_blank" rel="noopener">Lihat website ↗</a>
<form method="post" enctype="multipart/form-data" action="index.php?page=logout">
<?=csrf()?>
<button class="text-button">Keluar</button>
</form>
</div>
</aside>
<main class="admin-main">
<header class="admin-header">
<div>
<p class="eyebrow">MANAJEMEN WEBSITE</p>
<h1>
<?=e($modules[$tab])?>
</h1>
</div>
<span class="badge">Pengelola RSBL</span>
</header>
<?php if($error):?>
<div class="notice error" role="alert">
<?=e($error)?>
</div>
<?php endif;?>
<?php if(isset($_SESSION['flash'])):?>
<div class="notice">
<?=e($_SESSION['flash'])?>
</div>
<?php unset($_SESSION['flash']);endif;?>
<?php if($tab==='dashboard'):?>
<p>Selamat datang. Kelola informasi rumah sakit dan permohonan pasien dari sini.</p>
<div class="grid three stats">
<?php foreach([['Permohonan masuk',(int)$db->query('SELECT COUNT(*) FROM appointments')->fetchColumn()],['Menunggu verifikasi',(int)$db->query("SELECT COUNT(*) FROM appointments WHERE status='Menunggu verifikasi'")->fetchColumn()],['Konten aktif',(int)$db->query('SELECT COUNT(*) FROM contents WHERE active=1')->fetchColumn()]] as $stat):?>
<div class="panel">
<p>
<?=e($stat[0])?>
</p>
<strong>
<?=$stat[1]?>
</strong>
</div>
<?php endforeach;?>
</div>
<div class="panel">
<h2>Mulai mengelola</h2>
<div class="grid three">
<a class="admin-shortcut" href="index.php?page=admin&tab=contents&kind=slide">&#9639; <strong>Kelola slideshow beranda</strong>
<small>Unggah foto dan atur urutan &rarr;</small>
</a>
<a class="admin-shortcut" href="index.php?page=admin&tab=contents&kind=popup">✦ <strong>Ubah popup promo</strong>
<small>Atur isi dan periode tayang →</small>
</a>
<a class="admin-shortcut" href="index.php?page=admin&tab=doctors">✚ <strong>Perbarui jadwal dokter</strong>
<small>Kelola hari dan jam praktik →</small>
</a>
<a class="admin-shortcut" href="index.php?page=admin&tab=appointments">▤ <strong>Periksa pendaftaran</strong>
<small>Verifikasi permohonan masuk →</small>
</a>
</div>
</div>
<div class="notice">Sebelum dipublikasikan: ganti data contoh, verifikasi kontak dan jadwal, gunakan HTTPS, serta siapkan pencadangan database. Pendaftaran belum terhubung ke Medinfras.</div>
<?php elseif($tab==='settings'):?>
<form class="panel" method="post" enctype="multipart/form-data">
<?=csrf()?>
<input type="hidden" name="action" value="settings">
<h2>Identitas & kontak</h2>
<div class="form-grid">
<?php foreach(['name'=>'Nama rumah sakit','tagline'=>'Tagline','address'=>'Alamat','phone'=>'Telepon','whatsapp'=>'Nomor WhatsApp (format 628...)'] as $key=>$label)field($key,$label,setting($key));?>
</div>
<h2>Perusahaan & media sosial</h2>
<div class="form-grid">
<?php field('company_name','Nama perusahaan',setting('company_name'));foreach(['instagram'=>'Instagram','facebook'=>'Facebook','youtube'=>'YouTube','tiktok'=>'TikTok'] as $key=>$label)field($key,'URL '.$label,setting($key),'url',false);?>
</div>
<h2>Logo & gambar utama</h2>
<p class="muted">Logo rumah sakit, perusahaan, dan akreditasi tampil berdampingan pada header. Foto slideshow dikelola di Master Konten &rarr; Slideshow Beranda.</p>
<div class="form-grid">
<img class="admin-logo-preview" src="<?=e(brandingImage('company_image', 'assets/branding/hospital.png'))?>" alt="Logo perusahaan saat ini">
<img class="admin-logo-preview" src="<?=e(brandingImage('accreditation_image', 'assets/branding/accreditation.jpg'))?>" alt="Logo akreditasi saat ini">
</div>
<div class="form-grid">
<label>Logo perusahaan (maks. 10 MB)<input type="file" name="company_file" accept="image/jpeg,image/png,image/webp">
</label>
<label>Logo akreditasi (maks. 10 MB)<input type="file" name="accreditation_file" accept="image/jpeg,image/png,image/webp">
</label>
</div>
<label class="check">
<input type="checkbox" name="clear_company_image"> Gunakan kembali logo perusahaan bawaan</label>
<label class="check">
<input type="checkbox" name="clear_accreditation_image"> Gunakan kembali logo akreditasi bawaan</label>
<div class="form-grid">
<label>Upload logo (JPG/PNG/WebP, maks. 10 MB)<input type="file" name="logo_file" accept="image/jpeg,image/png,image/webp">
</label>
<label>Upload gambar utama (maks. 10 MB)<input type="file" name="hero_file" accept="image/jpeg,image/png,image/webp">
</label>
</div>
<label class="check">
<input type="checkbox" name="clear_logo_image"> Gunakan kembali logo rumah sakit bawaan</label>
<label class="check">
<input type="checkbox" name="clear_hero_image"> Gunakan kembali foto dokter bawaan</label>
<h2>Beranda & profil</h2>
<?php foreach(['hero_title'=>'Judul utama (Enter untuk baris baru)','hero_text'=>'Deskripsi utama','about'=>'Tentang rumah sakit'] as $key=>$label):?>
<label>
<?=$label?>
<textarea name="<?=$key?>" rows="4" required>
<?=e(setting($key))?>
</textarea>
</label>
<?php endforeach;?>
<div class="form-grid">
<label>Penanda data contoh<select name="demo">
<option value="1" <?=setting('demo')==='1'?'selected':''?>>Tampilkan</option>
<option value="0" <?=setting('demo')==='0'?'selected':''?>>Sembunyikan — setelah data diverifikasi</option>
</select>
</label>
<label>Popup beranda<select name="popup_enabled">
<option value="1" <?=setting('popup_enabled')==='1'?'selected':''?>>Aktif</option>
<option value="0" <?=setting('popup_enabled')==='0'?'selected':''?>>Nonaktif</option>
</select>
</label>
</div>
<button class="button">Simpan pengaturan</button>
</form>
<?php elseif (in_array($tab, ['contents', 'information'], true)): ?>
<?php if (!in_array($kind, array_merge(['service_slide', 'outpatient_photo', 'clinic', 'inpatient_room', 'emergency_photo'], facilityPhotoKinds(), informationKinds()), true)): ?>
<div class="notice">Slideshow beranda: pilih kategori <strong>Slideshow Beranda</strong>, unggah foto lebar, isi judul dan urutan. Minimal dua slide aktif untuk menampilkan tombol navigasi dan pergantian otomatis. Rekomendasi foto: 1920 × 800 piksel; hindari menaruh tulisan pada foto.</div>
<?php endif; ?>
<div class="tab-row">
<?php foreach ($kinds as $key => $label): ?>
<?php if ($tab === 'information' && !in_array($key, informationKinds(), true)) continue; ?>
<a class="<?=$kind===$key?'selected':''?>" href="index.php?page=admin&amp;tab=<?= $tab === 'information' ? 'information' : 'contents' ?>&amp;kind=<?= e($key) ?>">
<?=$label?>
</a>
<?php endforeach;?>
</div>
<?php $edit=query('SELECT * FROM contents WHERE id=? AND kind=?',[(int)($_GET['edit']??0),$kind])[0]??[];if($error&&($_POST['action']??'')==='content_save')$edit=$_POST;?>
<?php if (in_array($kind, informationKinds(), true)): ?>
<?php require __DIR__ . '/information-master.php'; ?>
<?php elseif (in_array($kind, facilityPhotoKinds(), true)): ?>
<?php require __DIR__ . '/facility-detail-master.php'; ?>
<?php elseif ($kind === 'emergency_photo'): ?>
<?php require __DIR__ . '/emergency-master.php'; ?>
<?php elseif ($kind === 'inpatient_room'): ?>
<?php require __DIR__ . '/inpatient-master.php'; ?>
<?php elseif ($kind === 'outpatient_photo'): ?>
<?php require __DIR__ . '/outpatient-master.php'; ?>
<?php elseif ($kind === 'clinic'): ?>
<?php require __DIR__ . '/clinic-master.php'; ?>
<?php elseif ($kind === 'service_slide'): ?>
<?php require __DIR__ . '/services-photo-master.php'; ?>
<?php elseif ($kind === 'history'): ?>
<?php require __DIR__ . '/history-master.php'; ?>
<?php elseif ($kind === 'vision'): ?>
<?php require __DIR__ . '/vision-master.php'; ?>
<?php elseif ($kind === 'quality'): ?>
<?php require __DIR__ . '/quality-master.php'; ?>
<?php else: ?>
<?php if ($kind === 'partner'): ?>
<form class="panel" method="post">
<?=csrf()?>
<input type="hidden" name="action" value="partner_heading">
<?php field('partner_heading', 'Judul bagian mitra di beranda', $_POST['partner_heading'] ?? setting('partner_heading', 'Mitra & Penjamin')); ?>
<label>Subjudul bagian mitra (opsional)<textarea name="partner_subtitle" rows="2" maxlength="1000" placeholder="Kami bekerja sama dengan berbagai perusahaan untuk memberikan kemudahan, keamanan, dan kenyamanan bagi Anda."><?= e($_POST['partner_subtitle'] ?? setting('partner_subtitle')) ?></textarea></label>
<button class="button">Simpan judul dan subjudul</button>
</form>
<?php endif; ?>
<div class="panel">
<h2>
<?=empty($edit['id'])?'Tambah':'Edit'?> <?=e($kinds[$kind])?>
</h2>
<form method="post" enctype="multipart/form-data">
<?=csrf()?>
<input type="hidden" name="action" value="content_save">
<input type="hidden" name="id" value="<?=e($edit['id']??0)?>">
<?php if ($kind === 'history'): ?>
<?php require __DIR__ . '/history-editor.php'; ?>
<?php else: ?>
<div class="form-grid">
<?php
field('title', $kind === 'slide' ? 'Judul (opsional)' : 'Judul', $edit['title'] ?? '', 'text', $kind !== 'slide');
if ($kind !== 'partner') field('subtitle', 'Label / subjudul (opsional)', $edit['subtitle'] ?? '', 'text', false);
?>
</div>
<label>Unggah gambar (JPG/PNG/WebP, maks. 10 MB)<input type="file" name="image_file" accept="image/jpeg,image/png,image/webp">
</label>
<?php if ($kind === 'slide') { require __DIR__ . '/slide-editor.php'; } ?>
<?php if ($kind !== 'partner'): ?>
<label>Isi konten<textarea name="body" rows="5" maxlength="50000" <?=$kind==='slide'?'':'required'?>>
<?=e($edit['body']??'')?>
</textarea>
</label>
<?php endif; ?>
<div class="form-grid">
<?php field('image','URL gambar HTTPS (opsional)',$edit['image']??'','text',false); if ($kind !== 'partner') { field('link','Tautan tujuan (opsional)',$edit['link']??'','text',false);field('starts','Mulai tayang (khusus popup)',$edit['starts']??'','date',false);field('ends','Akhir tayang (khusus popup)',$edit['ends']??'','date',false); field('sort_order','Urutan tampil (angka kecil di depan)',$edit['sort_order']??0,'number'); } ?>
</div>
<label class="check">
<input type="checkbox" name="active" <?=($edit['active']??1)?'checked':''?>> Aktif / dipublikasikan</label>
<p class="muted">Unggah gambar atau gunakan URL HTTPS. Unggahan baru diprioritaskan. Mitra aktif dengan gambar tampil di bagian paling bawah beranda. Periode tayang hanya berlaku untuk popup.</p>
<?php endif; ?>
<div class="actions">
<button class="button">Simpan konten</button>
<a href="index.php?page=admin&tab=contents&kind=<?=e($kind)?>">Batal / tambah baru</a>
</div>
</form>
</div>
<div class="panel table-wrap">
<table>
<thead>
<tr>
<th>Judul</th>
<th>Status</th>
<?php if ($kind !== 'partner'): ?><th>Urutan</th><?php endif; ?>
<th>Tindakan</th>
</tr>
</thead>
<tbody>
<?php foreach(query('SELECT * FROM contents WHERE kind=? ORDER BY sort_order,id DESC',[$kind]) as $row):?>
<tr>
<td>
<?=e($row['title'])?>
<?php if ($kind === 'history'): ?><small><?= e(historyTypes()[historyType((int) $row['id'])]) ?></small><?php endif; ?>
<?php if ($kind === 'partner' && $row['image']): ?><img class="admin-partner-thumbnail" src="<?= e(photo($row['image'])) ?>" alt="" loading="lazy"><?php endif; ?>
</td>
<td>
<?=$row['active']?'Aktif':'Draft'?>
</td>
<?php if ($kind !== 'partner'): ?><td><?=$row['sort_order']?></td><?php endif; ?>
<td>
<div class="actions">
<a href="index.php?page=admin&tab=contents&kind=<?=e($kind)?>&edit=<?=$row['id']?>">Edit</a>
<form method="post" enctype="multipart/form-data" data-confirm="Hapus konten ini?">
<?=csrf()?>
<input type="hidden" name="action" value="content_delete">
<input type="hidden" name="id" value="<?=$row['id']?>">
<button class="text-button danger">Hapus</button>
</form>
</div>
</td>
</tr>
<?php endforeach;?>
</tbody>
</table>
</div>
<?php endif; ?>
<?php elseif ($tab === 'doctors'):
    $edit = query('SELECT * FROM doctors WHERE id=?', [(int) ($_GET['edit'] ?? 0)])[0] ?? [];
    $profile = doctorProfile((int) ($edit['id'] ?? 0));
    if ($error && ($_POST['action'] ?? '') === 'doctor_save') {
        $edit = $_POST;
        $edit['days'] = implode(',', array_map('intval', $_POST['days'] ?? []));
        $edit['active'] = isset($_POST['active']) ? 1 : 0;
        $profile = $_POST;
    }
?>
<div class="notice">Satu data dokter digunakan untuk Daftar Dokter, Profil Dokter, dan Jadwal Dokter. Isi riwayat di bawah dan jadwal praktik pada formulir yang sama.</div>
<form class="panel" method="post" enctype="multipart/form-data">
<?=csrf()?>
<input type="hidden" name="action" value="doctor_save">
<input type="hidden" name="id" value="<?=$edit['id']??0?>">
<h2>
<?=empty($edit['id'])?'Tambah':'Edit'?> dokter</h2>
<div class="form-grid">
<?php field('name','Nama dokter',$edit['name']??'');field('specialty','Poli',$edit['specialty']??'');field('image','URL foto HTTPS (opsional)',$edit['image']??'','text',false);?>
</div>
<label>Unggah foto dokter (JPG/PNG/WebP, maks. 10 MB)<input type="file" name="image_file" accept="image/jpeg,image/png,image/webp">
</label>
<h3>Profil &amp; riwayat dokter</h3>
<?php foreach (['bio' => 'Tentang dokter', 'education' => 'Riwayat pendidikan', 'experience' => 'Pengalaman praktik', 'training' => 'Pelatihan', 'certifications' => 'Sertifikasi', 'organizations' => 'Keanggotaan organisasi'] as $key => $label): ?>
    <div class="history-editor" data-history-editor>
        <label for="history-<?= $key ?>"><?= e($label) ?> (opsional)</label>
        <div class="history-editor-surface">
            <div class="history-toolbar" role="group" aria-label="Format paragraf <?= e($label) ?>">
                <span class="history-toolbar-label">Paragraf</span>
                <button type="button" data-list="bullet" aria-label="Daftar bullet" title="Daftar bullet" aria-controls="history-<?= $key ?>">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="4" cy="6" r="1.5"/><circle cx="4" cy="12" r="1.5"/><circle cx="4" cy="18" r="1.5"/><path d="M9 6h12M9 12h12M9 18h12"/></svg>
                </button>
                <button type="button" data-list="number" aria-label="Daftar bernomor" title="Daftar bernomor" aria-controls="history-<?= $key ?>">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><text x="1" y="8">1</text><text x="1" y="14">2</text><text x="1" y="20">3</text><path d="M9 6h12M9 12h12M9 18h12"/></svg>
                </button>
                <button type="button" data-list="plain" aria-label="Hapus format daftar" title="Hapus format daftar" aria-controls="history-<?= $key ?>">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
                </button>
            </div>
            <textarea id="history-<?= $key ?>" name="<?= $key ?>" rows="5" maxlength="10000" placeholder="Tulis riwayat di sini..."><?= e($profile[$key] ?? '') ?></textarea>
        </div>
    </div>
<?php endforeach; ?>
<?php require __DIR__ . '/doctor-schedule-editor.php'; ?>
<label class="check">
<input type="checkbox" name="active" <?=($edit['active']??1)?'checked':''?>> Dokter aktif</label>
<div class="actions">
<button class="button">Simpan dokter</button>
<a href="index.php?page=admin&tab=doctors">Tambah baru</a>
</div>
</form>
<div class="panel table-wrap">
<table>
<thead>
<tr>
<th>Dokter</th>
<th>Poli</th>
<th>Jam WITA</th>
<th>Status</th>
<th>Tindakan</th>
</tr>
</thead>
<tbody>
<?php foreach(query('SELECT * FROM doctors ORDER BY name') as $row):?>
<tr>
<td>
<?=e($row['name'])?>
</td>
<td>
<?=e($row['specialty'])?>
</td>
<td>
<?= e(doctorScheduleText($row)) ?>
</td>
<td>
<?=$row['active']?'Aktif':'Nonaktif'?>
</td>
<td>
<a href="index.php?page=admin&tab=doctors&edit=<?=$row['id']?>">Edit</a>
<form method="post" enctype="multipart/form-data" data-confirm="Nonaktifkan dokter ini?">
<?=csrf()?>
<input type="hidden" name="action" value="doctor_archive">
<input type="hidden" name="id" value="<?=$row['id']?>">
<button class="text-button danger">Nonaktifkan</button>
</form>
</td>
</tr>
<?php endforeach;?>
</tbody>
</table>
</div>
<?php elseif($tab==='appointments'): $statusFilter=$_GET['status']??'';$validStatuses=['Menunggu verifikasi','Dikonfirmasi','Selesai','Dibatalkan'];if(!in_array($statusFilter,$validStatuses,true))$statusFilter='';$pageNo=max(1,(int)($_GET['p']??1));$offset=($pageNo-1)*25;$where=$statusFilter?' WHERE a.status=?':'';$args=$statusFilter?[$statusFilter]:[];$total=(int)query('SELECT COUNT(*) AS total FROM appointments a'.$where,$args)[0]['total'];$rows=query('SELECT a.*, d.name AS doctor_name FROM appointments a LEFT JOIN doctors d ON d.id=a.doctor_id'.$where.' ORDER BY a.id DESC LIMIT 25 OFFSET '.$offset,$args);?>
<div class="notice">Kode permohonan bukan nomor antrean. Perubahan status tidak mengirim notifikasi otomatis. Gunakan kontak pasien untuk konfirmasi.</div>
<div class="tab-row">
<a href="index.php?page=admin&tab=appointments">Semua (<?=$total?>)</a>
<?php foreach($validStatuses as $s):?>
<a class="<?=$s===$statusFilter?'selected':''?>" href="index.php?page=admin&tab=appointments&status=<?=urlencode($s)?>">
<?=e($s)?>
</a>
<?php endforeach;?>
</div>
<?php if(!$rows):?>
<div class="panel">Belum ada permohonan pada kategori ini.</div>
<?php endif;?>
<?php foreach($rows as $row):?>
<article class="panel appointment">
<div class="section-heading">
<div>
<p class="eyebrow">
<?=e($row['reference'])?>
</p>
<h3>
<?=e($row['patient_name'])?>
</h3>
</div>
<span class="badge">
<?=e($row['status'])?>
</span>
</div>
<p>
<?=e($row['doctor_name']??'Dokter tidak tersedia')?> · <?=e($row['visit_date'])?> · <?=e($row['payment'])?>
</p>
<p>Telepon: <a href="tel:<?=e(preg_replace('/[^+0-9]/','',$row['phone']))?>">
<?=e($row['phone'])?>
</a> · Dikirim <?=e($row['created_at'])?> WITA</p>
<form method="post" enctype="multipart/form-data">
<?=csrf()?>
<input type="hidden" name="action" value="appointment_update">
<input type="hidden" name="id" value="<?=$row['id']?>">
<label>Status<select name="status">
<?php foreach($validStatuses as $s):?>
<option <?=$s===$row['status']?'selected':''?>>
<?=e($s)?>
</option>
<?php endforeach;?>
</select>
</label>
<label>Catatan internal petugas<textarea name="notes" rows="2" maxlength="5000">
<?=e($row['notes'])?>
</textarea>
</label>
<button class="button small">Simpan status</button>
</form>
<form method="post" enctype="multipart/form-data" class="delete-row" data-confirm="Hapus permanen data permohonan ini?">
<?=csrf()?>
<input type="hidden" name="action" value="appointment_delete">
<input type="hidden" name="id" value="<?=$row['id']?>">
<button class="text-button danger">Hapus data permohonan</button>
</form>
</article>
<?php endforeach;?>
<div class="actions">
<?php if($pageNo>1):?>
<a href="index.php?page=admin&tab=appointments&status=<?=urlencode($statusFilter)?>&p=<?=$pageNo-1?>">← Sebelumnya</a>
<?php endif;?>
<span>Halaman <?=$pageNo?> · <?=$total?> data</span>
<?php if($offset+25<$total):?>
<a href="index.php?page=admin&tab=appointments&status=<?=urlencode($statusFilter)?>&p=<?=$pageNo+1?>">Berikutnya →</a>
<?php endif;?>
</div>
<?php elseif($tab==='account'):?>
<form class="panel narrow" method="post" enctype="multipart/form-data">
<?=csrf()?>
<input type="hidden" name="action" value="password">
<h2>Ganti kata sandi</h2>
<?php field('current_password','Kata sandi saat ini','','password');field('new_password','Kata sandi baru (minimal 12 karakter)','','password');?>
<button class="button">Perbarui kata sandi</button>
</form>
<?php endif;?>
</main>
</body>
</html>
