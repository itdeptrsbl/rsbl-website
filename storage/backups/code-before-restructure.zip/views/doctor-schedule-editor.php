<?php
$sessions = $error && isset($_POST['sessions'])
    ? (array) $_POST['sessions']
    : doctorSessions($edit);
$dayLabels = [1 => 'Senin', 2 => 'Selasa', 3 => 'Rabu', 4 => 'Kamis', 5 => 'Jumat', 6 => 'Sabtu', 7 => 'Minggu'];
?>
<section data-schedule-editor>
    <input type="hidden" name="schedule_editor" value="1">
    <h3>Jadwal praktik</h3>
    <p class="muted">Opsional. Kosongkan atau hapus semua sesi jika dokter tidak membuka praktik. Dokter tanpa jadwal tetap tampil di Daftar Dokter, tetapi tidak di Jadwal Dokter.</p>
    <div data-session-list>
        <?php foreach ($sessions as $index => $session): ?>
            <?php require __DIR__ . '/doctor-session-row.php'; ?>
        <?php endforeach; ?>
    </div>
    <button type="button" class="button small" data-add-session>+ Tambah sesi praktik</button>
    <p class="muted" data-session-message aria-live="polite"></p>
    <template data-session-template>
        <?php $index = '__INDEX__'; $session = ['days' => [], 'start' => '', 'end' => '']; ?>
        <?php require __DIR__ . '/doctor-session-row.php'; ?>
    </template>
</section>
