<?php if($page==='home'):?>
<?php require __DIR__ . '/home-hero.php'; ?>
<div class="container quick-links">
<a href="index.php?page=doctors">
<span class="quick-icon">✚</span>
<div>
<strong>Dokter & Jadwal</strong>
<small>Rencanakan kunjungan Anda</small>
</div>
<span>↗</span>
</a>
<a href="index.php?page=services">
<span class="quick-icon">♡</span>
<div>
<strong>Layanan Kami</strong>
<small>Perawatan sesuai kebutuhan</small>
</div>
<span>↗</span>
</a>
<a href="index.php?page=contact">
<span class="quick-icon">⌖</span>
<div>
<strong>Lokasi & Kontak</strong>
<small>Kami lebih dekat dari Anda</small>
</div>
<span>↗</span>
</a>
</div>
<section class="section container">
<div class="section-heading">
<div>
<p class="eyebrow">LAYANAN KESEHATAN</p>
<h2>Perawatan yang Anda butuhkan.<br>Perhatian yang Anda harapkan.</h2>
</div>
<a class="text-link" href="index.php?page=services">Lihat semua layanan ↗</a>
</div>
<div class="grid four">
<?php foreach(array_slice(records('service'),0,4) as $i=>$item):?>
<a class="service-card" href="index.php?page=detail&id=<?=$item['id']?>">
<span class="service-number">0<?=$i+1?>
</span>
<div class="service-icon">
<?= ['✚','⌂','♡','✧'][$i]?>
</div>
<h3>
<?=e($item['title'])?>
</h3>
<p>
<?=e($item['body'])?>
</p>
<span class="card-link">Selengkapnya ↗</span>
</a>
<?php endforeach;?>
</div>
</section>
<section class="soft-section doctor-showcase" data-doctor-carousel aria-label="Kenali tim dokter kami">
<div class="container section">
<div class="section-heading">
<div>
<p class="eyebrow">KENALI TIM KAMI</p>
<h2>Temukan dokter,<br>mulai langkah sehat Anda.</h2>
</div>
<div>
<p>Informasi dokter dan jadwal dalam satu tempat.</p>
<a class="text-link" href="index.php?page=doctors">Cari dokter & jadwal ↗</a>
</div>
</div>
<div class="doctor-carousel-shell">
<button class="doctor-carousel-arrow doctor-carousel-prev" type="button" data-doctor-prev aria-label="Lihat dokter sebelumnya" aria-controls="home-doctor-track" hidden>&larr;</button>
<div class="doctor-carousel-track" id="home-doctor-track" tabindex="0" role="region" aria-label="Pilihan dokter">
<?php foreach(query('SELECT * FROM doctors WHERE active=1 ORDER BY id') as $d):require __DIR__.'/doctor-card.php';endforeach;?>
</div>
<button class="doctor-carousel-arrow doctor-carousel-next" type="button" data-doctor-next aria-label="Lihat dokter berikutnya" aria-controls="home-doctor-track" hidden>&rarr;</button>
</div>
<div class="doctor-showcase-more">
<a class="button doctor-more-button" href="index.php?page=doctors">Lihat Selengkapnya</a>
</div>
</div>
</section>
<section class="section container">
<div class="feature-banner">
<div>
<p class="eyebrow">LEBIH MUDAH DARI MANA SAJA</p>
<h2>Rencanakan kunjungan,<br>tanpa harus datang dulu.</h2>
<p>Ajukan pendaftaran online. Petugas kami akan memverifikasi<br>jadwal dan mengonfirmasi kunjungan Anda.</p>
<a class="button light" href="index.php?page=register">Mulai Pendaftaran ↗</a>
</div>
<span class="banner-art" aria-hidden="true">✦</span>
</div>
</section>
<section class="section container compact-top">
<div class="section-heading">
<div>
<p class="eyebrow">RUANG INFORMASI</p>
<h2>Kabar baik untuk hidup lebih sehat.</h2>
</div>
<a class="text-link" href="index.php?page=news">Semua informasi ↗</a>
</div>
<div class="grid three">
<?php foreach(array_slice(array_merge(records('news'),records('event'),records('promo')),0,3) as $i=>$item):require __DIR__.'/article-card.php';endforeach;?>
</div>
</section>
<?php $partners = array_filter(records('partner'), fn($partner) => $partner['image'] !== ''); ?>
<?php if ($partners): ?>
<section class="container section home-partners" aria-labelledby="partners-heading">
    <div class="partner-heading"><h2 id="partners-heading"><?= e(setting('partner_heading', 'Mitra & Penjamin')) ?></h2></div>
    <?php if (setting('partner_subtitle') !== ''): ?>
    <p class="partner-subtitle"><?= e(setting('partner_subtitle')) ?></p>
    <?php endif; ?>
    <div class="partner-carousel-shell">
    <button class="partner-arrow partner-prev" type="button" aria-label="Mitra sebelumnya" aria-controls="partner-logos" hidden></button>
    <div class="home-partner-logos" id="partner-logos" role="region" aria-label="Logo mitra" tabindex="0">
        <?php foreach ($partners as $partner): ?>
            <figure><img src="<?= e(photo($partner['image'])) ?>" alt="<?= e($partner['title']) ?>" loading="lazy"></figure>
        <?php endforeach; ?>
    </div>
    <button class="partner-arrow partner-next" type="button" aria-label="Mitra berikutnya" aria-controls="partner-logos" hidden></button>
    </div>
</section>
<?php endif; ?>
<?php $popups=records('popup');$popup=null;foreach($popups as $candidate){if(($candidate['starts']===''||$candidate['starts']<=date('Y-m-d'))&&($candidate['ends']===''||$candidate['ends']>=date('Y-m-d'))){$popup=$candidate;break;}}if($popup && setting('popup_enabled')==='1'):?>
<dialog id="promo-dialog" data-key="<?=e(hash('sha256',json_encode($popup)))?>">
<button class="dialog-close" aria-label="Tutup informasi">×</button>
<?php if($popup['image']):?>
<img class="popup-image" src="<?=e(photo($popup['image']))?>" alt="<?=e($popup['title'])?>">
<?php endif;?>
<p class="eyebrow">
<?=e($popup['subtitle'])?>
</p>
<h2>
<?=e($popup['title'])?>
</h2>
<p>
<?=nl2br(e($popup['body']))?>
</p>
<a class="button" href="<?=e($popup['link']?:'index.php?page=register')?>">Selengkapnya ↗</a>
</dialog>
<?php endif;?>
<?php elseif (in_array($page, ['doctors', 'doctor_schedule', 'doctor_profile'], true)): ?>
<?php require __DIR__ . '/doctor-pages.php'; ?>
<?php elseif (isset(facilityPhotoPages()[$page])): ?>
<?php require __DIR__ . '/facility-detail-page.php'; ?>
<?php elseif ($page === 'emergency'): ?>
<?php require __DIR__ . '/emergency-page.php'; ?>
<?php elseif ($page === 'inpatient'): ?>
<?php require __DIR__ . '/inpatient-page.php'; ?>
<?php elseif ($page === 'outpatient'): ?>
<?php require __DIR__ . '/outpatient-page.php'; ?>
<?php elseif ($page === 'services'): ?>
<?php require __DIR__ . '/services-page.php'; ?>
<?php elseif ($page === 'news'): ?>
<section class="page-intro container">
<p class="eyebrow">
RUANG INFORMASI
</p>
<h1>
Informasi untuk Anda.
</h1>
<p class="lead">
Berita, kegiatan, dan informasi layanan rumah sakit.
</p>
</section>
<section class="section compact-top container">
<div class="grid three">
<?php
$items = query('SELECT * FROM contents WHERE active=1 AND kind IN (?,?,?,?) ORDER BY id DESC', informationKinds());
foreach ($items as $i => $item) {
    require __DIR__ . '/article-card.php';
}
?>
<?php if (!$items): ?><p>Belum ada informasi yang dipublikasikan.</p><?php endif; ?>
</div>
</section>
<?php elseif($page==='detail'): $item=query('SELECT * FROM contents WHERE id=? AND active=1',[(int)($_GET['id']??0)])[0]??null;if(!$item){http_response_code(404);}?>
<?php if ($item && in_array($item['kind'], informationKinds(), true)): ?>
<?php require __DIR__ . '/information-detail.php'; ?>
<?php else: ?>
<section class="container section narrow">
<a class="text-link" href="index.php">← Beranda</a>
<p class="eyebrow">
<?=e($item['subtitle']??'INFORMASI')?>
</p>
<h1>
<?=e($item['title']??'Halaman tidak ditemukan')?>
</h1>
<?php if($item && $item['image']):?>
<img class="detail-image" src="<?=e(photo($item['image']))?>" alt="<?=e($item['title'])?>">
<?php endif;?>
<p class="article-body">
<?=nl2br(e($item['body']??'Informasi tidak tersedia.'))?>
</p>
<?php if(!empty($item['link'])):?>
<a class="button" href="<?=e($item['link'])?>">Informasi lebih lanjut ↗</a>
<?php endif;?>
</section>
<?php endif; ?>
<?php elseif ($page === 'history'): ?>
<?php require __DIR__ . '/history-page.php'; ?>
<?php elseif ($page === 'vision'): ?>
<?php require __DIR__ . '/vision-page.php'; ?>
<?php elseif ($page === 'quality'): ?>
<?php require __DIR__ . '/quality-page.php'; ?>
<?php elseif($page==='about'):?>
<section class="container page-intro">
<p class="eyebrow">TENTANG KAMI</p>
<h1>Dekat dengan Anda.<br>Melayani dalam kasih.</h1>
<p class="lead">
<?=nl2br(e(setting('about')))?>
</p>
</section>
<section class="container section compact-top">
<div class="grid three">
<?php foreach(records('page') as $i=>$item):require __DIR__.'/article-card.php';endforeach;?>
</div>
</section>
<?php elseif($page==='contact'):?>
<section class="container page-intro">
<p class="eyebrow">HUBUNGI KAMI</p>
<h1>Kami siap membantu.</h1>
<p class="lead">Informasi kunjungan, layanan, dan kebutuhan Anda.</p>
</section>
<section class="container section compact-top">
<div class="grid three">
<article class="panel">
<h3>Alamat</h3>
<p>
<?=e(setting('address'))?>
</p>
<a class="text-link" href="https://www.google.com/maps/search/?api=1&query=<?=rawurlencode(setting('address'))?>" target="_blank" rel="noopener">Buka petunjuk arah ↗</a>
</article>
<article class="panel">
<h3>Telepon</h3>
<p>
<?=e(setting('phone'))?>
</p>
<a class="text-link" href="tel:<?=e(preg_replace('/[^+0-9]/','',setting('phone')))?>">Telepon rumah sakit ↗</a>
</article>
<article class="panel">
<h3>WhatsApp</h3>
<p>Tanyakan informasi layanan kepada petugas.</p>
<a class="text-link" href="https://wa.me/<?=e(preg_replace('/\D/','',setting('whatsapp')))?>" target="_blank" rel="noopener">Hubungi petugas ↗</a>
</article>
</div>
<div class="notice">Kondisi darurat: datang langsung ke IGD atau hubungi rumah sakit. Formulir online tidak dipantau sebagai saluran darurat.</div>
</section>
<?php elseif($page==='register'):?>
<section class="container page-intro">
<p class="eyebrow">PENDAFTARAN ONLINE</p>
<h1>Langkah pertama,<br>menuju perawatan Anda.</h1>
<p class="lead">Isi permohonan kunjungan. Petugas akan memeriksa dan mengonfirmasi pendaftaran Anda.</p>
</section>
<section class="container section compact-top registration-layout">
<div class="panel">
<?php if($success):?>
<div class="success-mark">✓</div>
<h2>Permohonan tersimpan.</h2>
<p>Kode referensi Anda:</p>
<strong class="reference">
<?=e($success)?>
</strong>
<p>Simpan kode ini. Permohonan masih <strong>menunggu verifikasi petugas</strong> dan belum menjadi nomor antrean.</p>
<p>Hubungi rumah sakit untuk konfirmasi. Tidak ada pesan WhatsApp otomatis yang dikirim.</p>
<a class="button" href="index.php?page=contact">Hubungi petugas ↗</a>
<?php else:?>
<h2>Data kunjungan</h2>
<?php if($error):?>
<div class="notice error" role="alert">
<?=e($error)?>
</div>
<?php endif;?>
<form method="post">
<?=csrf()?>
<div class="form-grid">
<?php field('patient_name','Nama lengkap',$_POST['patient_name']??'');field('phone','Nomor WhatsApp / telepon',$_POST['phone']??'','tel');?>
</div>
<label>Dokter / Poliklinik<select name="doctor_id" required>
<option value="">Pilih dokter dan perhatikan hari praktik</option>
<?php foreach($doctors as $d):?>
<option value="<?=$d['id']?>" <?=((int)($_POST['doctor_id'] ?? $_GET['doctor_id'] ?? 0)===(int)$d['id'])?'selected':''?>>
<?= e($d['name'] . ' - ' . $d['specialty'] . ' | ' . doctorScheduleText($d)) ?>
</option>
<?php endforeach;?>
</select>
</label>
<div class="form-grid">
<label>Tanggal kunjungan<input type="date" name="visit_date" min="<?=date('Y-m-d')?>" max="<?=date('Y-m-d',strtotime('+30 days'))?>" value="<?=e($_POST['visit_date']??'')?>" required>
</label>
<label>Pembiayaan<select name="payment" required>
<option value="">Pilih pembiayaan</option>
<?php foreach(['Pribadi','BPJS','Asuransi'] as $pay):?>
<option <?=($_POST['payment']??'')===$pay?'selected':''?>>
<?=$pay?>
</option>
<?php endforeach;?>
</select>
</label>
</div>
<p class="muted">Ketersediaan layanan dan persyaratan penjamin akan dikonfirmasi petugas.</p>
<label class="honeypot" aria-hidden="true">Website<input name="website" tabindex="-1" autocomplete="off">
</label>
<label class="check">
<input type="checkbox" name="consent" value="1" required> Saya menyetujui penggunaan nama dan nomor telepon untuk memproses serta menghubungi saya terkait permohonan ini. Data hanya dapat diakses pengelola.</label>
<button class="button">Kirim Permohonan ↗</button>
</form>
<?php endif;?>
</div>
<aside>
<div class="panel pale">
<span class="eyebrow">SEBELUM MENDAFTAR</span>
<h3>Lebih siap,<br>lebih nyaman.</h3>
<ol class="steps">
<li>Pilih dokter dan tanggal sesuai hari praktik.</li>
<li>Isi data diri serta nomor yang dapat dihubungi.</li>
<li>Simpan kode permohonan dan tunggu konfirmasi petugas.</li>
</ol>
<hr>
<p>Pendaftaran ini belum terintegrasi dengan Medinfras dan tidak menjamin kuota atau nomor antrean.</p>
<a class="text-link" href="index.php?page=contact">Butuh bantuan? Hubungi kami ↗</a>
</div>
</aside>
</section>
<?php endif;?>
