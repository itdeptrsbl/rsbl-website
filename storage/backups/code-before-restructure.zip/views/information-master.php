<?php
if ($error && ($_POST['action'] ?? '') === 'information_save') {
    $edit = $_POST;
    $edit['active'] = isset($_POST['active']) ? 1 : 0;
}
$storedItem = query('SELECT * FROM contents WHERE id=? AND kind=?', [(int) ($edit['id'] ?? 0), $kind])[0] ?? null;
$informationImages = $storedItem ? informationPhotos($storedItem) : [];
?>
<div class="notice">Tambahkan judul, isi, dan foto melalui formulir ini. Klik + untuk membuat field foto baru; setiap foto punya keterangan dan pengaturan sendiri. Centang Publikasikan, lalu Simpan informasi. Halaman daftar menampilkan sampul; semua foto tampil setelah informasi dibuka.</div>
<form class="panel" method="post" enctype="multipart/form-data">
    <?= csrf() ?>
    <input type="hidden" name="action" value="information_save">
    <input type="hidden" name="id" value="<?= (int) ($edit['id'] ?? 0) ?>">
    <h2><?= empty($edit['id']) ? 'Tambah informasi' : 'Edit informasi' ?></h2>
    <?php field('title', 'Judul informasi', $edit['title'] ?? ''); ?>
    <div class="history-editor" data-history-editor>
        <label for="information-body">Isi informasi</label>
        <div class="history-editor-surface">
            <div class="history-toolbar" role="group" aria-label="Format isi informasi">
                <span class="history-toolbar-label">Paragraf</span>
                <button type="button" data-list="bullet" title="Daftar bullet" aria-label="Daftar bullet">&bull;</button>
                <button type="button" data-list="number" title="Daftar angka" aria-label="Daftar angka">1.</button>
                <button type="button" data-list="plain" title="Hapus format daftar" aria-label="Hapus format daftar">T</button>
            </div>
            <textarea id="information-body" name="body" rows="10" maxlength="50000" required><?= e($edit['body'] ?? '') ?></textarea>
        </div>
    </div>
    <h3>Video informasi (opsional)</h3>
    <label>Unggah video MP4 / WebM, maksimal 50 MB
        <input type="file" name="information_video" accept="video/mp4,video/webm">
    </label>
    <p class="muted">Kosongkan jika tidak ingin mengganti video lama. Video baru akan menggantikan video sebelumnya.</p>
    <?php $savedVideo = $storedItem ? informationVideo((int) $storedItem['id']) : ''; ?>
    <?php if ($savedVideo !== ''): ?>
        <video class="information-video" controls preload="metadata" playsinline src="<?= e($savedVideo) ?>">Browser Anda tidak mendukung pemutaran video.</video>
        <label class="check"><input type="checkbox" name="remove_information_video"> Hapus video tersimpan</label>
    <?php endif; ?>
    <h3>Foto-foto informasi</h3>
    <p class="muted">Foto opsional. Foto pertama menjadi sampul informasi. Klik + untuk menambahkan field foto, maksimal 10 MB per gambar.</p>
    <div class="inpatient-master-photos inpatient-adjustable-photos">
        <?php foreach ($informationImages as $photoIndex => $photo): ?>
            <div>
                <div data-room-adjust data-field-prefix="photo_display[<?= $photoIndex ?>]" data-display="<?= e(json_encode($_POST['photo_display'][$photoIndex] ?? ($photo['display'] ?? ['fit' => 'contain']))) ?>">
                    <img src="<?= e(photo($photo['src'])) ?>" alt="Foto informasi <?= $photoIndex + 1 ?>" draggable="false">
                </div>
                <label>Keterangan foto <?= $photoIndex + 1 ?>
                    <input name="photo_captions[<?= $photoIndex ?>]" maxlength="255" value="<?= e($_POST['photo_captions'][$photoIndex] ?? $photo['caption']) ?>">
                </label>
                <label class="check"><input type="checkbox" name="remove_photos[]" value="<?= $photoIndex ?>"> Hapus foto</label>
            </div>
        <?php endforeach; ?>
    </div>
    <div data-room-upload-list>
        <?php $uploadIndex = 0; require __DIR__ . '/inpatient-upload-row.php'; ?>
    </div>
    <template data-room-upload-template>
        <?php $uploadIndex = '__INDEX__'; require __DIR__ . '/inpatient-upload-row.php'; ?>
    </template>
    <script src="assets/inpatient-photo-editor.js?v=<?= filemtime(dirname(__DIR__) . '/assets/inpatient-photo-editor.js') ?>" defer></script>
    <label class="check"><input type="checkbox" name="active" <?= ($edit['active'] ?? 1) ? 'checked' : '' ?>> Publikasikan informasi (hapus centang untuk draft)</label>
    <div class="actions">
        <button class="button">Simpan informasi</button>
        <a href="index.php?page=admin&amp;tab=<?= $tab === 'information' ? 'information' : 'contents' ?>&amp;kind=<?= e($kind) ?>">Batal / tambah baru</a>
    </div>
</form>
<div class="panel table-wrap">
    <h2>Daftar <?= e($kinds[$kind]) ?></h2>
    <table>
        <thead><tr><th>Judul</th><th>Foto</th><th>Status</th><th>Tindakan</th></tr></thead>
        <tbody>
            <?php $informationRows = query('SELECT * FROM contents WHERE kind=? ORDER BY id DESC', [$kind]); ?>
            <?php foreach ($informationRows as $row): ?>
                <tr>
                    <td><?= e($row['title']) ?></td>
                    <td><?= count(informationPhotos($row)) ?></td>
                    <td><?= $row['active'] ? 'Aktif' : 'Draft' ?></td>
                    <td><div class="actions">
                        <a href="index.php?page=admin&amp;tab=<?= $tab === 'information' ? 'information' : 'contents' ?>&amp;kind=<?= e($kind) ?>&amp;edit=<?= (int) $row['id'] ?>">Edit</a>
                        <?php if ($row['active']): ?><a href="index.php?page=detail&amp;id=<?= (int) $row['id'] ?>" target="_blank" rel="noopener">Lihat</a><?php endif; ?>
                        <form method="post" data-confirm="Hapus informasi ini?">
                            <?= csrf() ?>
                            <input type="hidden" name="action" value="content_delete">
                            <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                            <button class="text-button danger">Hapus</button>
                        </form>
                    </div></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$informationRows): ?><tr><td colspan="4">Belum ada informasi.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
