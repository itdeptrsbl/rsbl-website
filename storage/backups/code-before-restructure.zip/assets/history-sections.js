document.querySelectorAll('[data-history-editor]').forEach(editor => {
    const select = editor.querySelector('[data-history-type]');
    function update() {
        editor.querySelectorAll('[data-history-for]').forEach(group => {
            group.hidden = !group.dataset.historyFor.split(',').includes(select.value);
        });
    }
    select.addEventListener('change', update);
    update();
});
