<?php

require __DIR__ . '/app/bootstrap.php';

$page = $_GET['page'] ?? 'home';
$allowed = [
    'home', 'doctors', 'doctor_schedule', 'doctor_profile', 'services', 'outpatient', 'inpatient', 'emergency', 'farmasi', 'radiologi', 'fisioterapi', 'laboratorium', 'news',
    'about', 'history', 'vision', 'quality', 'register', 'contact', 'detail', 'login', 'admin', 'logout', 'install',
];

if (!is_string($page) || !in_array($page, $allowed, true)) {
    http_response_code(404);
    exit('Halaman tidak ditemukan.');
}
if (!installed() && $page !== 'install') {
    go('index.php?page=install');
}
if ($page === 'install') {
    require __DIR__ . '/views/install.php';
    exit;
}
if ($page === 'logout') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        exit;
    }
    verifyCsrf();
    $_SESSION = [];
    session_regenerate_id(true);
    go('index.php');
}
if ($page === 'login') {
    require __DIR__ . '/views/login.php';
    exit;
}

require __DIR__ . '/app/doctors.php';
require __DIR__ . '/app/services.php';
require __DIR__ . '/app/inpatient.php';
require __DIR__ . '/app/information.php';
require __DIR__ . '/app/emergency.php';
require __DIR__ . '/app/history.php';
require __DIR__ . '/app/vision.php';

if ($page === 'admin') {
    adminOnly();
    require __DIR__ . '/app/admin.php';
    require __DIR__ . '/views/admin.php';
    exit;
}

$error = '';
$success = '';
if ($page === 'register') {
    require __DIR__ . '/app/registration.php';
}
if ($page === 'doctor_profile') {
    $doctor = query('SELECT * FROM doctors WHERE id=? AND active=1', [(int) ($_GET['id'] ?? 0)])[0] ?? null;
    if (!$doctor) {
        http_response_code(404);
    }
}

require __DIR__ . '/views/header.php';
require __DIR__ . '/views/public.php';
require __DIR__ . '/views/footer.php';
