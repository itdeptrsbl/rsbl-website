<?php

require_once __DIR__ . '/branding.php';

// Semua perubahan master wajib melalui autentikasi dan token CSRF.
$modules = [
    'dashboard' => 'Ringkasan',
    'settings' => 'Pengaturan Website',
    'contents' => 'Master Konten',
    'information' => 'Informasi',
    'doctors' => 'Dokter & Jadwal',
    'appointments' => 'Pendaftaran',
    'account' => 'Akun Saya',
];

$kinds = [
    'slide' => 'Slideshow Beranda',
    'service_slide' => 'Foto Fasilitas & Layanan',
    'outpatient_photo' => 'Rawat Jalan',
    'inpatient_room' => 'Rawat Inap & Kamar',
    'emergency_photo' => 'Instalasi Gawat Darurat',
    'clinic' => 'Daftar Poli',
    'service' => 'Layanan',
    'news' => 'Informasi / Berita',
    'event' => 'Acara',
    'promo' => 'Promo',
    'popup' => 'Popup',
    'page' => 'Halaman Informasi',
    'partner' => 'Mitra',
    'history' => 'Sejarah',
    'vision' => 'Visi & Misi',
    'quality' => 'Laporan Mutu',
    'career' => 'Karier',
];

foreach (facilityPhotoPages() as $facilityPage) {
    $kinds[$facilityPage['kind']] = $facilityPage['title'];
}

$tab = $_GET['tab'] ?? 'dashboard';
if (!isset($modules[$tab])) {
    $tab = 'dashboard';
}

$kind = $_GET['kind'] ?? 'service';
if (!isset($kinds[$kind])) {
    $kind = 'service';
}

if ($tab === 'information' && !in_array($kind, informationKinds(), true)) {
    $kind = 'news';
}

$error = '';

function safeLink(string $link): bool
{
    return $link === ''
        || preg_match('~^https://[^\s]+$~i', $link)
        || preg_match('~^index\.php(?:\?[^\s]*)?$~', $link);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = $_POST['action'] ?? '';

    try {
        if ($action === 'information_save') {
            saveInformation($kind);
        } elseif ($action === 'facility_intro') {
            saveFacilityIntro();
        } elseif ($action === 'emergency_save') {
            saveEmergencyContent();
        } elseif (in_array($action, ['inpatient_page', 'inpatient_save', 'inpatient_delete'], true)) {
            saveInpatient($action);
        } elseif ($action === 'outpatient_intro') {
            $intro = trim($_POST['outpatient_intro'] ?? '');
            if (strlen($intro) > 10000) {
                throw new RuntimeException('Penjelasan Rawat Jalan maksimal 10.000 karakter.');
            }
            if (query('SELECT name FROM settings WHERE name=?', ['outpatient_intro'])) {
                execute('UPDATE settings SET value=? WHERE name=?', [$intro, 'outpatient_intro']);
            } else {
                execute('INSERT INTO settings (name,value) VALUES (?,?)', ['outpatient_intro', $intro]);
            }
            flash('Penjelasan Rawat Jalan disimpan.');
        } elseif ($action === 'vision_save') {
            $content = validateVisionContent($_POST);
            $value = json_encode($content, JSON_UNESCAPED_UNICODE);
            if (query('SELECT name FROM settings WHERE name=?', ['vision_content'])) {
                execute('UPDATE settings SET value=? WHERE name=?', [$value, 'vision_content']);
            } else {
                execute('INSERT INTO settings (name,value) VALUES (?,?)', ['vision_content', $value]);
            }
            flash('Visi, Misi, Janji, Motto, dan Nilai-Nilai disimpan.');
        } elseif ($action === 'partner_heading') {
            $heading = trim($_POST['partner_heading'] ?? '');
            $subtitle = trim($_POST['partner_subtitle'] ?? '');
            if ($heading === '' || strlen($heading) > 255) throw new RuntimeException('Judul mitra wajib diisi, maksimal 255 karakter.');
            if (strlen($subtitle) > 1000) throw new RuntimeException('Subjudul mitra maksimal 1.000 karakter.');
            if (query('SELECT name FROM settings WHERE name=?', ['partner_heading'])) {
                execute('UPDATE settings SET value=? WHERE name=?', [$heading, 'partner_heading']);
            } else {
                execute('INSERT INTO settings (name,value) VALUES (?,?)', ['partner_heading', $heading]);
            }
            if (query('SELECT name FROM settings WHERE name=?', ['partner_subtitle'])) {
                execute('UPDATE settings SET value=? WHERE name=?', [$subtitle, 'partner_subtitle']);
            } else {
                execute('INSERT INTO settings (name,value) VALUES (?,?)', ['partner_subtitle', $subtitle]);
            }
            flash('Judul dan subjudul mitra disimpan.');
        } elseif ($action === 'settings') {
            foreach ([
                'logo_image' => 'logo_file',
                'hero_image' => 'hero_file',
                'company_image' => 'company_file',
                'accreditation_image' => 'accreditation_file',
            ] as $key => $field) {
                $uploaded = uploadImage($field);
                if ($uploaded !== '') {
                    execute('UPDATE settings SET value=? WHERE name=?', [$uploaded, $key]);
                }
                if (isset($_POST['clear_' . $key])) {
                    execute('UPDATE settings SET value=? WHERE name=?', ['', $key]);
                }
            }

            $keys = [
                'name', 'tagline', 'hero_title', 'hero_text', 'address',
                'phone', 'whatsapp', 'about', 'demo', 'popup_enabled',
                'company_name', 'instagram', 'facebook', 'youtube', 'tiktok',
            ];

            foreach ($keys as $key) {
                $value = trim($_POST[$key] ?? '');
                if (
                    in_array($key, ['instagram', 'facebook', 'youtube', 'tiktok'], true)
                    && $value !== ''
                    && !preg_match('~^https://[^\s]+$~i', $value)
                ) {
                    throw new RuntimeException('Tautan sosial harus dimulai dengan https://');
                }
                if (strlen($value) > 10000) {
                    throw new RuntimeException('Isi pengaturan terlalu panjang.');
                }
                execute('UPDATE settings SET value=? WHERE name=?', [$value, $key]);
            }

            flash('Pengaturan website disimpan.');
        } elseif ($action === 'content_save') {
            $historyType = $_POST['history_type'] ?? 'text';
            if ($kind === 'history' && (!is_string($historyType) || !isset(historyTypes()[$historyType]))) {
                throw new RuntimeException('Pilih jenis bagian sejarah yang valid.');
            }
            if ($kind === 'history' && $historyType === 'organization') {
                $organizationWidth = filter_var($_POST['organization_width'] ?? 100, FILTER_VALIDATE_INT);
                if ($organizationWidth === false || !in_array($organizationWidth, range(20, 100, 10), true)) {
                    throw new RuntimeException('Pilih ukuran gambar struktur organisasi antara 20% dan 100%.');
                }
            }
            if ($kind === 'history' && $historyType === 'leader') {
                $leaderPhotoSize = filter_var($_POST['leader_photo_zoom'] ?? 100, FILTER_VALIDATE_INT);
                if ($leaderPhotoSize === false || !in_array($leaderPhotoSize, range(100, 200, 10), true)) {
                    throw new RuntimeException('Zoom foto pemimpin harus antara 100% dan 200%.');
                }
                $leaderPosition = [];
                foreach (['x' => 50, 'y' => 30] as $axis => $defaultPosition) {
                    $position = filter_var($_POST['leader_photo_' . $axis] ?? $defaultPosition, FILTER_VALIDATE_INT);
                    if ($position === false || !in_array($position, range(0, 100, 5), true)) throw new RuntimeException('Posisi foto pemimpin tidak valid.');
                    $leaderPosition[$axis] = $position;
                }
            }
            $slideDisplay = null;
            if (in_array($kind, array_merge(['slide', 'service_slide', 'outpatient_photo', 'clinic', 'emergency_photo'], facilityPhotoKinds()), true)) {
                $fit = $_POST['slide_fit'] ?? ($kind === 'clinic' ? 'contain' : 'cover');
                $zoom = filter_var($_POST['slide_zoom'] ?? 100, FILTER_VALIDATE_INT);
                $x = filter_var($_POST['slide_x'] ?? 50, FILTER_VALIDATE_INT);
                $y = filter_var($_POST['slide_y'] ?? 50, FILTER_VALIDATE_INT);
                if (!in_array($fit, ['cover', 'contain'], true)
                    || $zoom === false || $zoom < ($kind === 'clinic' ? 50 : 100) || $zoom > ($kind === 'clinic' ? 400 : 160)
                    || $x === false || $x < 0 || $x > 100
                    || $y === false || $y < 0 || $y > 100) {
                    throw new RuntimeException('Pengaturan ukuran atau posisi foto tidak valid.');
                }
                $slideDisplay = compact('fit', 'zoom', 'x', 'y');
            }

            $title = trim($_POST['title'] ?? '');
            $body = trim($_POST['body'] ?? '');
            $image = trim($_POST['image'] ?? '');
            $link = trim($_POST['link'] ?? '');
            if ($kind === 'quality') {
                $existingQuality = query('SELECT * FROM contents WHERE id=? AND kind=?', [(int) ($_POST['id'] ?? 0), 'quality'])[0] ?? [];
                $image = $existingQuality['image'] ?? '';
                $body = '';
                $link = '';
            }
            if ($kind === 'history') {
                $existingHistory = query('SELECT * FROM contents WHERE id=? AND kind=?', [(int) ($_POST['id'] ?? 0), 'history'])[0] ?? [];
                $image = $existingHistory['image'] ?? '';
                if ($historyType === 'leader') {
                    $uploadToken = $_POST['leader_upload_token'] ?? '';
                    if (!is_string($uploadToken) || !preg_match('/^[a-f0-9]{32}$/', $uploadToken)) {
                        $uploadToken = bin2hex(random_bytes(16));
                        $_POST['leader_upload_token'] = $uploadToken;
                    }
                    $pendingPhoto = $_SESSION['leader_uploads'][$uploadToken] ?? null;
                    if ($pendingPhoto && (int) $pendingPhoto['id'] === (int) ($_POST['id'] ?? 0)) $image = $pendingPhoto['path'];
                }
                $link = $historyType === 'video' ? ($existingHistory['link'] ?? '') : '';
                if ($historyType === 'video') {
                    $uploadedVideo = uploadHistoryVideo('video_file');
                    if ($uploadedVideo !== '') $link = $uploadedVideo;
                    if (!historyVideo($link)) throw new RuntimeException('Unggah video sejarah MP4 atau WebM (maksimal 20 MB).');
                }
            }

            if (
                (!in_array($kind, array_merge(['slide', 'service_slide', 'outpatient_photo', 'emergency_photo'], facilityPhotoKinds()), true) && $title === '')
                || strlen($title) > 255
                || strlen($body) > 50000
                || strlen($_POST['subtitle'] ?? '') > 255
            ) {
                throw new RuntimeException(
                    in_array($kind, array_merge(['slide', 'service_slide', 'outpatient_photo', 'emergency_photo'], facilityPhotoKinds()), true)
                        ? 'Judul dan subjudul maksimal 255 karakter; isi maksimal 50.000 karakter.'
                        : 'Judul wajib diisi (maksimal 255 karakter); isi maksimal 50.000 karakter.'
                );
            }
            if (
                (!safeLink($link) && !($kind === 'history' && preg_match('~^assets/uploads/[a-f0-9]{32}\.(mp4|webm)$~', $link)))
                || (
                    $image !== ''
                    && !preg_match('~^https://[^\s]+$~i', $image)
                    && !preg_match('~^assets/uploads/[a-f0-9]{32}\.(jpg|png|webp)$~', $image)
                )
            ) {
                throw new RuntimeException('Gambar harus URL HTTPS. Tautan harus HTTPS atau index.php?page=...');
            }

            $uploaded = uploadImage('image_file', in_array($kind, ['history', 'quality'], true) ? 20 : 10);
            if ($uploaded !== '') {
                $image = $uploaded;
                if ($kind === 'history' && $historyType === 'leader') {
                    $_SESSION['leader_uploads'][$uploadToken] = ['id' => (int) ($_POST['id'] ?? 0), 'path' => $uploaded];
                }
            }

            if (in_array($kind, array_merge(['service_slide', 'outpatient_photo', 'emergency_photo'], facilityPhotoKinds()), true) && $image === '') {
                throw new RuntimeException('Unggah foto fasilitas atau masukkan URL gambar.');
            }

            if ($kind === 'clinic') {
                $specialty = trim($_POST['subtitle'] ?? '');
                if ($specialty === '') {
                    throw new RuntimeException('Isi poli penghubung sesuai field poliklinik dokter.');
                }
            }

            $start = $_POST['starts'] ?? '';
            if ($kind === 'quality' && $image === '') throw new RuntimeException('Unggah gambar laporan mutu (JPG, PNG, atau WebP; maksimal 20 MB).');
            $end = $_POST['ends'] ?? '';
            if ($kind === 'history' && $historyType === 'leader' && (trim($_POST['subtitle'] ?? '') === '' || $start === '')) {
                throw new RuntimeException('Isi jabatan dan tahun atau tanggal mulai menjabat.');
            }
            if ($kind === 'history' && $historyType === 'leader' && $image === '') {
                throw new RuntimeException('Unggah foto pemimpin (maksimal 20 MB).');
            }
            if ($kind === 'history' && $historyType === 'leader') {
                $start = historyTenureValue($start);
                $end = historyTenureValue($end);
                $startBound = strlen($start) === 4 ? $start . '-01-01' : $start;
                $endBound = strlen($end) === 4 ? $end . '-12-31' : $end;
                if ($end !== '' && $endBound < $startBound) throw new RuntimeException('Akhir masa jabatan tidak boleh sebelum awal masa jabatan.');
            } elseif (
                ($start !== '' && !validDate($start))
                || ($end !== '' && !validDate($end))
                || ($start !== '' && $end !== '' && $end < $start)
            ) {
                throw new RuntimeException('Periksa urutan tanggal tayang.');
            }

            $values = [
                $title,
                trim($_POST['subtitle'] ?? ''),
                $body,
                $image,
                $link,
                $start,
                $end,
                isset($_POST['active']) ? 1 : 0,
                (int) ($_POST['sort_order'] ?? 0),
            ];
            $id = (int) ($_POST['id'] ?? 0);

            if ($id) {
                execute('UPDATE contents SET title=?,subtitle=?,body=?,image=?,link=?,starts=?,ends=?,active=?,sort_order=? WHERE id=? AND kind=?', [...$values, $id, $kind]);
            } else {
                execute('INSERT INTO contents (title,subtitle,body,image,link,starts,ends,active,sort_order,kind) VALUES (?,?,?,?,?,?,?,?,?,?)', [...$values, $kind]);
            }

            if ($slideDisplay !== null) {
                $savedId = $id ?: (int) $db->lastInsertId();
                $displayKey = 'slide_display_' . $savedId;
                $displayValue = json_encode($slideDisplay);
                if (query('SELECT name FROM settings WHERE name=?', [$displayKey])) {
                    execute('UPDATE settings SET value=? WHERE name=?', [$displayValue, $displayKey]);
                } else {
                    execute('INSERT INTO settings (name,value) VALUES (?,?)', [$displayKey, $displayValue]);
                }
            }

            if ($kind === 'history') {
                $savedId = $id ?: (int) $db->lastInsertId();
                $typeKey = 'history_type_' . $savedId;
                if ($historyType === 'leader') {
                    $photoSizeKey = 'history_leader_zoom_' . $savedId;
                    foreach ($leaderPosition as $axis => $position) {
                        $positionKey = 'history_leader_' . $axis . '_' . $savedId;
                        if (query('SELECT name FROM settings WHERE name=?', [$positionKey])) {
                            execute('UPDATE settings SET value=? WHERE name=?', [(string) $position, $positionKey]);
                        } else {
                            execute('INSERT INTO settings (name,value) VALUES (?,?)', [$positionKey, (string) $position]);
                        }
                    }
                    if (query('SELECT name FROM settings WHERE name=?', [$photoSizeKey])) {
                        execute('UPDATE settings SET value=? WHERE name=?', [(string) $leaderPhotoSize, $photoSizeKey]);
                    } else {
                        execute('INSERT INTO settings (name,value) VALUES (?,?)', [$photoSizeKey, (string) $leaderPhotoSize]);
                    }
                }
                if (query('SELECT name FROM settings WHERE name=?', [$typeKey])) {
                    execute('UPDATE settings SET value=? WHERE name=?', [$historyType, $typeKey]);
                } else {
                    execute('INSERT INTO settings (name,value) VALUES (?,?)', [$typeKey, $historyType]);
                }
                if ($historyType === 'organization') {
                    $widthKey = 'history_width_' . $savedId;
                    if (query('SELECT name FROM settings WHERE name=?', [$widthKey])) {
                        execute('UPDATE settings SET value=? WHERE name=?', [(string) $organizationWidth, $widthKey]);
                    } else {
                        execute('INSERT INTO settings (name,value) VALUES (?,?)', [$widthKey, (string) $organizationWidth]);
                    }
                }
            }

            if ($kind === 'history' && $historyType === 'leader') unset($_SESSION['leader_uploads'][$uploadToken]);
            flash('Konten disimpan.');
        } elseif ($action === 'content_delete') {
            execute('DELETE FROM contents WHERE id=? AND kind=?', [(int) $_POST['id'], $kind]);
            flash('Konten dihapus.');
        } elseif ($action === 'doctor_save') {
            $profile = [];
            foreach (['bio', 'education', 'experience', 'training', 'certifications', 'organizations'] as $key) {
                $profile[$key] = trim($_POST[$key] ?? '');
                if (strlen($profile[$key]) > 10000) {
                    throw new RuntimeException('Setiap bagian riwayat dokter maksimal 10.000 karakter.');
                }
            }

            $name = trim($_POST['name'] ?? '');
            $specialty = trim($_POST['specialty'] ?? '');
            $hours = trim($_POST['hours'] ?? '');
            $image = trim($_POST['image'] ?? '');

            $days = array_values(array_unique(array_filter(
                array_map('intval', $_POST['days'] ?? []),
                fn($n) => $n >= 1 && $n <= 7
            )));
            sort($days);

            if (isset($_POST['sessions']) || isset($_POST['schedule_editor'])) {
                $submittedSessions = $_POST['sessions'] ?? [];
                if (!is_array($submittedSessions) || count($submittedSessions) > 14) {
                    throw new RuntimeException('Maksimal 14 sesi praktik.');
                }
                $sessions = [];
                $days = [];
                foreach ($submittedSessions as $session) {
                    $sessionDays = array_values(array_unique(array_filter(
                        array_map('intval', (array) ($session['days'] ?? [])),
                        fn($day) => $day >= 1 && $day <= 7
                    )));
                    sort($sessionDays);
                    $start = $session['start'] ?? '';
                    $end = $session['end'] ?? '';
                    if (!$sessionDays && $start === '' && $end === '') continue;
                    if (!$sessionDays || !preg_match('/^([01][0-9]|2[0-3]):[0-5][0-9]$/', $start)
                        || !preg_match('/^([01][0-9]|2[0-3]):[0-5][0-9]$/', $end) || $end <= $start) {
                        throw new RuntimeException('Setiap sesi wajib memiliki hari dan jam selesai setelah jam mulai.');
                    }
                    $sessions[] = ['days' => $sessionDays, 'start' => $start, 'end' => $end];
                    $days = array_merge($days, $sessionDays);
                }
                $days = array_values(array_unique($days));
                sort($days);
                $hours = $sessions ? $sessions[0]['start'] . '-' . $sessions[0]['end'] : '';
                $profile['sessions'] = $sessions;
            }


            if (
                $name === ''
                || $specialty === ''
                || strlen($name) > 255
                || strlen($specialty) > 255
                || strlen($hours) > 100
            ) {
                throw new RuntimeException('Isi nama dan poliklinik. Periksa panjang data dokter.');
            }
            if (
                $image !== ''
                && !preg_match('~^https://[^\s]+$~i', $image)
                && !preg_match('~^assets/uploads/[a-f0-9]{32}\.(jpg|png|webp)$~', $image)
            ) {
                throw new RuntimeException('Foto harus URL HTTPS atau unggahan lokal.');
            }

            $uploaded = uploadImage('image_file', 10);
            if ($uploaded !== '') {
                $image = $uploaded;
            }

            $values = [
                $name,
                $specialty,
                implode(',', $days),
                $hours,
                $image,
                isset($_POST['active']) ? 1 : 0,
            ];
            $id = (int) ($_POST['id'] ?? 0);

            if ($id) {
                execute('UPDATE doctors SET name=?,specialty=?,days=?,hours=?,image=?,active=? WHERE id=?', [...$values, $id]);
            } else {
                execute('INSERT INTO doctors (name,specialty,days,hours,image,active) VALUES (?,?,?,?,?,?)', $values);
            }

            $savedId = $id ?: (int) $db->lastInsertId();
            $profileKey = 'doctor_profile_' . $savedId;
            if (query('SELECT name FROM settings WHERE name=?', [$profileKey])) {
                execute('UPDATE settings SET value=? WHERE name=?', [json_encode($profile), $profileKey]);
            } else {
                execute('INSERT INTO settings (name,value) VALUES (?,?)', [$profileKey, json_encode($profile)]);
            }

            flash('Profil dokter dan jadwal disimpan.');
        } elseif ($action === 'doctor_archive') {
            execute('UPDATE doctors SET active=0 WHERE id=?', [(int) $_POST['id']]);
            flash('Dokter dinonaktifkan. Riwayat pendaftaran tetap tersimpan.');
        } elseif ($action === 'appointment_update') {
            $status = $_POST['status'] ?? '';
            $notes = trim($_POST['notes'] ?? '');

            if (
                !in_array($status, ['Menunggu verifikasi', 'Dikonfirmasi', 'Selesai', 'Dibatalkan'], true)
                || strlen($notes) > 5000
            ) {
                throw new RuntimeException('Status atau catatan tidak valid.');
            }

            execute('UPDATE appointments SET status=?,notes=? WHERE id=?', [$status, $notes, (int) $_POST['id']]);
            flash('Status pendaftaran disimpan.');
        } elseif ($action === 'appointment_delete') {
            execute('DELETE FROM appointments WHERE id=?', [(int) $_POST['id']]);
            flash('Data permohonan dihapus.');
        } elseif ($action === 'password') {
            $user = query('SELECT * FROM users WHERE id=?', [$_SESSION['admin_id']])[0];
            $new = $_POST['new_password'] ?? '';

            if (
                !password_verify($_POST['current_password'] ?? '', $user['password'])
                || strlen($new) < 12
                || strlen($new) > 128
            ) {
                throw new RuntimeException('Kata sandi lama salah atau kata sandi baru kurang dari 12 karakter.');
            }

            execute('UPDATE users SET password=? WHERE id=?', [password_hash($new, PASSWORD_DEFAULT), $_SESSION['admin_id']]);
            session_regenerate_id(true);
            flash('Kata sandi diperbarui.');
        } else {
            throw new RuntimeException('Tindakan tidak dikenal.');
        }

        go('index.php?page=admin&tab=' . urlencode($tab) . '&kind=' . urlencode($kind));
    } catch (RuntimeException $ex) {
        $error = $ex instanceof PDOException
            ? 'Perubahan tidak dapat disimpan. Periksa database.'
            : $ex->getMessage();
    }
}
