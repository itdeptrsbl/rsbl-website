<?php
// Permohonan ini tidak membuat nomor antrean SIMRS. Petugas wajib memverifikasi.
$doctors=query('SELECT * FROM doctors WHERE active=1 ORDER BY name');
if($_SERVER['REQUEST_METHOD']==='POST'){
 verifyCsrf();$name=trim($_POST['patient_name']??'');$phone=trim($_POST['phone']??'');$date=$_POST['visit_date']??'';$payment=$_POST['payment']??'';
 $doctor=query('SELECT * FROM doctors WHERE id=? AND active=1',[(int)($_POST['doctor_id']??0)])[0]??null;
 if(strlen($name)<3||strlen($name)>150)$error='Nama harus terdiri dari 3–150 karakter.';
 elseif(!preg_match('/^(?:\+62|62|0)[0-9]{8,13}$/',$phone))$error='Isi nomor telepon Indonesia yang valid.';
 elseif(!validDate($date)||$date<date('Y-m-d')||$date>date('Y-m-d',strtotime('+30 days')))$error='Tanggal kunjungan harus hari ini sampai 30 hari ke depan.';
 elseif(!$doctor||!scheduleMatches($doctor,$date))$error='Dokter tidak memiliki jadwal contoh pada hari tersebut. Pilih tanggal sesuai hari praktik.';
 elseif(!in_array($payment,['Pribadi','BPJS','Asuransi'],true))$error='Pilih jenis pembiayaan.';
 elseif(empty($_POST['consent']))$error='Persetujuan penggunaan data diperlukan.';
 elseif(!empty($_POST['website']))$error='Permohonan tidak dapat diproses.';
 elseif(time()-(int)($_SESSION['last_registration']??0)<60)$error='Tunggu satu menit sebelum mengirim permohonan berikutnya.';
 else {
  $ref='BL-'.date('ymd').'-'.strtoupper(bin2hex(random_bytes(4)));
  execute('INSERT INTO appointments (reference,patient_name,phone,doctor_id,visit_date,payment,status,notes,created_at) VALUES (?,?,?,?,?,?,?,?,?)',[$ref,$name,$phone,$doctor['id'],$date,$payment,'Menunggu verifikasi','',date('Y-m-d H:i:s')]);
  $_SESSION['last_registration']=time();$_SESSION['receipt']=$ref;go('index.php?page=register&sent=1');
 }
}
if(isset($_GET['sent'])&&isset($_SESSION['receipt']))$success=$_SESSION['receipt'];
