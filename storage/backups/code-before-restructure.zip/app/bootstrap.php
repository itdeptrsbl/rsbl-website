<?php
// Bootstrap bersama: konfigurasi, sesi aman, database, dan fungsi pembantu.
$config = require dirname(__DIR__).'/config.php';
date_default_timezone_set($config['timezone']);
session_set_cookie_params(['httponly'=>true,'secure'=>$config['secure_cookie'],'samesite'=>'Lax']);
session_start();
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: default-src 'self'; img-src 'self' https: data: blob:; media-src 'self' https:; frame-src https://www.youtube-nocookie.com; style-src 'self'; script-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'");
try {
    if ($config['driver']==='mysql') {
        $m=$config['mysql'];
        $db=new PDO("mysql:host={$m['host']};port={$m['port']};dbname={$m['database']};charset=utf8mb4",$m['username'],$m['password']);
    } else {
        $db=new PDO('sqlite:'.dirname(__DIR__).'/storage/rsbl.sqlite');
        $db->exec('PRAGMA foreign_keys = ON');
    }
    $db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    http_response_code(503); exit('Database belum tersedia. Periksa config.php dan ekstensi PDO sesuai README.');
}
// Semua isi dari database ditampilkan sebagai teks aman, bukan HTML mentah.
function e($value): string { return htmlspecialchars((string)$value,ENT_QUOTES,'UTF-8'); }
function go(string $url): void { header('Location: '.$url);exit; }
function csrf(): string { if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32));return '<input type="hidden" name="csrf" value="'.e($_SESSION['csrf']).'">'; }
function verifyCsrf(): void { if(empty($_SESSION['csrf'])||!is_string($_POST['csrf']??null)||!hash_equals($_SESSION['csrf']??'',$_POST['csrf'])) {http_response_code(419);exit('Sesi formulir kedaluwarsa. Muat ulang halaman.');} }
function installed(): bool { global $db;try {return (int)$db->query('SELECT COUNT(*) FROM users')->fetchColumn()>0;}catch(Throwable $e){return false;} }
function query(string $sql,array $args=[]): array {global $db;$q=$db->prepare($sql);$q->execute($args);return $q->fetchAll();}
function execute(string $sql,array $args=[]): void {global $db;$q=$db->prepare($sql);$q->execute($args);}
function setting(string $key,string $fallback=''): string { $rows=query('SELECT value FROM settings WHERE name=?',[$key]);return $rows[0]['value']??$fallback; }
function records(string $kind): array { return query('SELECT * FROM contents WHERE kind=? AND active=1 ORDER BY sort_order, id DESC',[$kind]); }
function adminOnly(): void {if(empty($_SESSION['admin_id']))go('index.php?page=login');header('Cache-Control: no-store');}
function flash(string $message): void {$_SESSION['flash']=$message;}
function field(string $name,string $label,$value='',string $type='text',bool $required=true): void {
    echo '<label>'.e($label).'<input type="'.e($type).'" name="'.e($name).'" value="'.e($value).'" '.($required?'required':'').' maxlength="'.($type==='password'?'128':'255').'"></label>';
}
function photo(string $url): string {return preg_match('~^https://[^\s]+$~i',$url)||preg_match('~^assets/uploads/[a-f0-9]{32}\.(jpg|png|webp)$~',$url)?$url:'assets/care.svg';}
function validDate(string $date): bool {$d=DateTime::createFromFormat('!Y-m-d',$date);return $d && $d->format('Y-m-d')===$date;}
function scheduleMatches(array $doctor,string $date): bool {return in_array((int)date('N',strtotime($date)),array_map('intval',explode(',',$doctor['days'])),true);}

// Unggah hanya gambar raster yang lolos pemeriksaan tipe dan dimensi, tanpa SVG atau kode.
function uploadImage(string $field, int $maxMb = 10): string
{
    $file = $_FILES[$field] ?? null;
    if (!$file || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return '';
    }
    if ($file['error'] !== UPLOAD_ERR_OK || $file['size'] > $maxMb * 1024 * 1024) {
        throw new RuntimeException('Gambar maksimal ' . $maxMb . ' MB. Periksa batas upload PHP.');
    }

    $size = @getimagesize($file['tmp_name']);
    $types = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!$size || !isset($types[$size['mime']]) || $size[0] > 6000 || $size[1] > 6000) {
        throw new RuntimeException('Unggah JPG, PNG, atau WebP dengan dimensi maksimal 6000 piksel.');
    }

    $path = 'assets/uploads/' . bin2hex(random_bytes(16)) . '.' . $types[$size['mime']];
    if (!move_uploaded_file($file['tmp_name'], dirname(__DIR__) . '/' . $path)) {
        throw new RuntimeException('Folder assets/uploads tidak dapat ditulis.');
    }
    return $path;
}
