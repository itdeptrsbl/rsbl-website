<?php
// Router untuk server PHP bawaan; hanya index dan aset publik yang boleh diakses.
$path=rawurldecode(parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH)??'/');
if(preg_match('~^/assets/uploads/[a-f0-9]{32}\.(mp4|webm)$~',$path)&&is_file(__DIR__.$path))return false;
if(preg_match('~^/assets/(?:(?:uploads|branding)/)?[a-zA-Z0-9_.-]+\.(css|js|svg|png|jpg|webp)$~',$path)&&is_file(__DIR__.$path))return false;
if($path==='/'||$path==='/index.php'){require __DIR__.'/index.php';return true;}
http_response_code(404);echo 'Halaman tidak ditemukan.';
