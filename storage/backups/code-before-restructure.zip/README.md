# RS Bintang Laut — Website PHP

Paket review lokal, PHP native terstruktur + PDO. Tidak menggunakan Laravel, Composer, atau Node. Semua aset desain tersedia lokal dan tidak memerlukan CDN. Ilustrasi adalah aset contoh, bukan foto dokter atau logo resmi rumah sakit.

## Jalankan di Windows / XAMPP (paling mudah)

1. Ekstrak ZIP. Pindahkan folder `rsbl-website` ke `C:\xampp\htdocs\rsbl-website`.
2. Buka XAMPP Control Panel dan klik **Start Apache**.
3. Buka **http://localhost/rsbl-website/**.
4. Pada layar instalasi, isi email admin dan kata sandi minimal 12 karakter, lalu klik **Pasang website**.
5. Login pengelola tersedia di footer atau **http://localhost/rsbl-website/index.php?page=login**.

SQLite aktif sebagai default agar tidak perlu mengimpor SQL. File database dibuat otomatis di `storage/rsbl.sqlite`. Jika muncul `Database belum tersedia`, buka `C:\xampp\php\php.ini`, aktifkan `extension=pdo_sqlite`, simpan, lalu restart Apache. Aktifkan juga `extension=mbstring` bila belum aktif. PHP 8.0+ diperlukan (XAMPP 8.0.30 dapat digunakan).

Alternatif: klik dua kali `start.bat` (lokasi PHP diasumsikan `C:\xampp\php\php.exe`), lalu buka http://localhost:8080. Apache tidak perlu dijalankan untuk cara ini.

## Menggunakan MySQL XAMPP

Pilih sebelum instalasi pertama. Data SQLite tidak otomatis dipindahkan ke MySQL.

1. Jalankan Apache dan MySQL di XAMPP.
2. Buka http://localhost/phpmyadmin dan buat database `rsbl_website` dengan collation `utf8mb4_unicode_ci`.
3. Buka `config.php`, ubah `driver` menjadi `mysql`, sesuaikan host, port, database, username, password.
4. Buka website dan lakukan instalasi; tabel dan data contoh dibuat otomatis. Aktifkan `pdo_mysql` di php.ini bila diperlukan.
5. Pada hosting, gunakan user database khusus dengan kata sandi, bukan akun root.

## Halaman publik

Beranda, profil dan halaman informasi, dokter + pencarian langsung + jadwal, layanan, berita/acara/promo/karier, detail konten, kontak dan petunjuk arah, formulir pendaftaran, bukti permohonan. Tidak ada login pasien.

## Panel admin

- Ringkasan jumlah permohonan dan konten.
- Pengaturan identitas, judul/deskripsi beranda, alamat, telepon, WhatsApp, profil, penanda review, tombol aktif popup.
- Master konten: layanan, berita, acara, promo, popup, halaman informasi, mitra, karier. Tambah, edit, hapus, draft/aktif, urutan.
- Gambar konten dan foto dokter dapat diunggah melalui admin (JPG/PNG/WebP maksimal 3 MB untuk gambar konten dan 5 MB untuk foto dokter, dimensi maksimal 6000 piksel) atau memakai URL HTTPS. Logo dan gambar utama dapat diunggah melalui Pengaturan Website. Simbol dan ilustrasi bawaan tampil jika belum diganti. Folder `assets/uploads` harus dapat ditulis PHP. Gambar unggahan bersifat publik: jangan unggah data atau dokumen pasien. File gambar lama tidak otomatis dihapus agar tautan lain tetap aman; bersihkan berkala jika sudah tidak dipakai.
- Popup: judul, subjudul, isi, gambar, tautan, rentang tanggal. Tampil pada beranda sekali per versi konten per tab browser. Saat diedit, popup dapat tampil kembali. Pilihan dengan urutan terkecil diprioritaskan. Tanggal tayang hanya untuk popup.
- Master dokter: nama, poliklinik, foto URL, hari dan satu rentang jam praktik, aktif/nonaktif. Belum mendukung jadwal berbeda per hari, kuota, cuti, atau pengecualian hari libur.
- Pendaftaran: daftar dengan filter status dan paginasi, detail kontak, catatan internal, status, hapus data.
- Akun: ganti kata sandi. Satu peran pengelola; belum tersedia manajemen banyak akun atau reset kata sandi melalui email.

Mitra tampil sebagai daftar teks di footer. Berita, acara, promo, karier tampil pada halaman Informasi. Halaman informasi dapat dibuka dari Tentang Kami. Tidak ada klaim data dokter asli: semua dokter dan jadwal dalam paket menggunakan nama contoh.

## Alur pendaftaran

Pasien memilih dokter dan tanggal, mengisi nama + telepon + pembiayaan, menyetujui pemrosesan data, lalu menerima kode referensi acak. Validasi hari praktik dan tanggal maksimal 30 hari dilakukan di server. Data tersimpan pada database yang sama dengan panel admin.

Kode tersebut **bukan nomor antrean SIMRS**. Permohonan berstatus **Menunggu verifikasi** sampai petugas mengonfirmasi secara manual. Tidak ada pesan WhatsApp, SMS, atau email otomatis. Tombol WhatsApp hanya membuka kontak rumah sakit. Pilihan BPJS/asuransi bukan jaminan kelayakan; harus diverifikasi petugas. Formulir bukan saluran darurat. Jangan masukkan data pasien asli saat review.

## Struktur

- `index.php`: pintu masuk dan routing dengan daftar halaman yang diizinkan.
- `config.php`: koneksi database, zona waktu WITA, cookie HTTPS.
- `app/bootstrap.php`: sesi, database, escaping, CSRF, fungsi bersama.
- `app/schema.php` / `seed.php`: tabel dan data contoh instalasi.
- `app/admin.php`: validasi dan penyimpanan master.
- `app/registration.php`: validasi dan pencatatan permohonan.
- `views/`: template publik, admin, login, dan instalasi.
- `assets/`: CSS responsif, interaksi JavaScript, ilustrasi SVG lokal.
- `storage/`: database SQLite. Dilindungi `.htaccess` pada Apache.
- `router.php`: pembatasan akses untuk server PHP bawaan.

## Pengujian manual saat review

1. Install, login, buka panel admin.
2. Ubah popup, judul beranda, nomor WhatsApp; periksa hasil pada website publik.
3. Buat berita, nonaktifkan, lalu aktifkan kembali; pastikan status mengubah visibilitas.
4. Tambah dokter + hari praktik. Cari dokter di halaman publik.
5. Daftar pada tanggal yang sesuai; simpan referensi; pastikan muncul di admin.
6. Daftar pada hari tidak sesuai; pastikan server menolak.
7. Ubah status menjadi Dikonfirmasi; muat ulang dan pastikan tersimpan.
8. Cek pada layar lebar, tablet, dan mobile; menu mobile, popup (termasuk Escape), serta formulir.
9. Logout, coba buka URL admin; harus kembali ke login.
10. Coba akses `/storage/rsbl.sqlite` dan `/config.php` dari browser; harus ditolak/404.

## Batas kesiapan sebelum produksi

Ini fondasi review fungsional, belum audit produksi. Perlu migrasi isi Wix beserta foto/logo resmi dan pemetaan URL lama, verifikasi jadwal/kontak, peninjauan informasi medis, integrasi API Medinfras, kuota dan antrean, kebijakan privasi/retensi, backup, pemulihan akun, pengujian beban, dan audit akses. Pertimbangkan Laravel saat fitur, jumlah pengelola, dan integrasi bertambah.

Aktifkan HTTPS dan `secure_cookie => true`. Apache harus mengizinkan `.htaccess` (`AllowOverride All`); jika memakai Nginx, konfigurasi sendiri larangan akses `app`, `views`, `storage`, `tests`, `config.php`, README, dan file internal. Installer otomatis terkunci setelah akun pertama dibuat; lakukan instalasi pertama hanya dari lingkungan lokal/terbatas. Jangan memasang paket kosong sebelum akun dibuat pada domain publik.

Perlindungan dasar tersedia: password_hash/verify, regenerasi sesi, CSRF, prepared statement, escaping HTML, allowlist routing/tautan, header keamanan, pembatasan login 5 percobaan/IP per 15 menit. Pembatasan formulir per sesi + honeypot adalah dasar review; tambahkan pembatasan IP/CAPTCHA pada produksi. Sesi belum memiliki timeout khusus, belum ada audit log, dan enkripsi database belum diterapkan. Batasi akses backup dan disk server.

## Backup / reset lokal

SQLite: hentikan server lalu salin `storage/rsbl.sqlite` dan folder `assets/uploads` ke lokasi aman. MySQL: ekspor melalui phpMyAdmin. Untuk mengulang instalasi lokal SQLite, hentikan server dan hapus database tersebut; **semua konten, akun, dan permohonan akan hilang**. Untuk MySQL gunakan database baru kosong.
